import express from 'express'
import cors from 'cors'
import { createServer } from 'http'
import { Server } from 'socket.io' // optional realtime
import {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
} from '@whiskeysockets/baileys'
import QRCode from 'qrcode'
import pino from 'pino'
import { existsSync, rmSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const logger = pino({ level: 'silent' }) // ganti 'debug' kalau mau verbose

// ── Express setup ──────────────────────────────────────────────
const app  = express()
const http = createServer(app)

app.use(cors())
app.use(express.json())
app.use(express.static(join(__dirname, 'public')))

// ── State global bot ───────────────────────────────────────────
let sock        = null
let qrCode      = null        // base64 PNG
let pairCode    = null        // string 8 digit
let botStatus   = 'disconnected'  // 'disconnected' | 'connecting' | 'connected'
let botNumber   = null

const SESSION_DIR = join(__dirname, 'sessions')

// ── Fungsi utama: start / connect WA ──────────────────────────
async function startWhatsApp(phoneNumber = null) {
  botStatus = 'connecting'
  qrCode    = null
  pairCode  = null

  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR)
  const { version } = await fetchLatestBaileysVersion()

  sock = makeWASocket({
    version,
    logger,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, logger),
    },
    printQRInTerminal: !phoneNumber, // QR di terminal kalau tidak pakai pairing code
    browser: ['NEXUS BOT', 'Chrome', '120.0'],
  })

  // ── Pairing code (jika nomor diberikan & belum registrasi) ──
  if (phoneNumber && !sock.authState.creds.registered) {
    // Tunggu sebentar baru minta kode
    await new Promise(r => setTimeout(r, 3000))
    try {
      const clean = phoneNumber.replace(/\D/g, '') // strip non-digit
      const code  = await sock.requestPairingCode(clean)
      pairCode    = code?.match(/.{1,4}/g)?.join('-') ?? code
      console.log(`✅ Pairing Code untuk ${clean}: ${pairCode}`)
    } catch (err) {
      console.error('❌ Gagal minta pairing code:', err.message)
    }
  }

  // ── Event: QR ──────────────────────────────────────────────
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update

    if (qr) {
      qrCode = await QRCode.toDataURL(qr)
      console.log('📷 QR Code baru dihasilkan')
    }

    if (connection === 'close') {
      const code    = lastDisconnect?.error?.output?.statusCode
      const reason  = DisconnectReason

      botStatus = 'disconnected'
      sock      = null

      if (code === reason.loggedOut) {
        console.log('🔴 Logged out — hapus sesi')
        if (existsSync(SESSION_DIR)) rmSync(SESSION_DIR, { recursive: true })
      } else if (code !== reason.loggedOut) {
        console.log('🔄 Reconnecting...')
        setTimeout(() => startWhatsApp(), 3000)
      }
    }

    if (connection === 'open') {
      botStatus = 'connected'
      botNumber = sock.user?.id?.split(':')[0] ?? null
      pairCode  = null
      qrCode    = null
      console.log(`🟢 Bot terhubung sebagai ${botNumber}`)
    }
  })

  // ── Simpan kredensial tiap update ──────────────────────────
  sock.ev.on('creds.update', saveCreds)

  // ── Handler pesan masuk ────────────────────────────────────
  sock.ev.on('messages.upsert', async ({ messages }) => {
    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe) continue

      const from = msg.key.remoteJid
      const text = (
        msg.message.conversation ||
        msg.message.extendedTextMessage?.text ||
        ''
      ).toLowerCase().trim()

      console.log(`📩 Pesan dari ${from}: ${text}`)

      // Contoh command handler
      if (text === '!ping')  await sock.sendMessage(from, { text: '🏓 Pong! Bot aktif.' })
      if (text === '!help')  await sock.sendMessage(from, { text: helpText() })
      if (text === '!info')  await sock.sendMessage(from, { text: infoText() })
    }
  })
}

function helpText() {
  return `╔══════════════════╗
║  *NEXUS BOT* 👑  ║
╚══════════════════╝

Perintah tersedia:
• !ping  — Cek bot aktif
• !help  — Menu bantuan
• !info  — Info bot

_Powered by NEXUS Premium_`
}

function infoText() {
  return `*NEXUS BOT INFO*
Status  : 🟢 Online
Nomor   : ${botNumber ?? '-'}
Version : v2.4.0
Library : Baileys`
}

// ══════════════════════════════════════════════════════════════
// API ENDPOINTS
// ══════════════════════════════════════════════════════════════

// GET /api/status — status koneksi bot
app.get('/api/status', (req, res) => {
  res.json({
    status   : botStatus,
    number   : botNumber,
    pairCode : pairCode,
    hasQR    : !!qrCode,
  })
})

// GET /api/qr — ambil QR code sebagai base64 PNG
app.get('/api/qr', (req, res) => {
  if (!qrCode) return res.status(404).json({ error: 'QR belum tersedia' })
  res.json({ qr: qrCode })
})

// POST /api/pair — minta pairing code dengan nomor WA
// Body: { "phone": "628123456789" }
app.post('/api/pair', async (req, res) => {
  const { phone } = req.body
  if (!phone) return res.status(400).json({ error: 'Nomor WA wajib diisi' })

  // Jika bot sudah jalan, stop dulu
  if (sock) {
    try { await sock.logout() } catch {}
    sock = null
  }
  if (existsSync(SESSION_DIR)) rmSync(SESSION_DIR, { recursive: true })

  // Start ulang dengan nomor untuk pairing code
  startWhatsApp(phone)

  // Poll sampai pairCode tersedia (max 10 detik)
  let tries = 0
  const interval = setInterval(() => {
    tries++
    if (pairCode) {
      clearInterval(interval)
      return res.json({ pairCode })
    }
    if (tries >= 20) {
      clearInterval(interval)
      return res.status(408).json({ error: 'Timeout: gagal minta kode. Coba lagi.' })
    }
  }, 500)
})

// POST /api/logout — logout & hapus sesi
app.post('/api/logout', async (req, res) => {
  try {
    if (sock) await sock.logout()
  } catch {}
  sock       = null
  botStatus  = 'disconnected'
  botNumber  = null
  if (existsSync(SESSION_DIR)) rmSync(SESSION_DIR, { recursive: true })
  res.json({ ok: true })
})

// POST /api/send — kirim pesan (untuk testing)
// Body: { "to": "628123456789", "text": "Halo!" }
app.post('/api/send', async (req, res) => {
  if (!sock || botStatus !== 'connected')
    return res.status(503).json({ error: 'Bot belum terhubung' })

  const { to, text } = req.body
  if (!to || !text) return res.status(400).json({ error: 'to & text wajib diisi' })

  try {
    await sock.sendMessage(`${to}@s.whatsapp.net`, { text })
    res.json({ ok: true })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── Start server ───────────────────────────────────────────────
const PORT = process.env.PORT || 3000
http.listen(PORT, () => {
  console.log(`🚀 NEXUS BOT backend jalan di http://localhost:${PORT}`)
  console.log(`📋 API siap: /api/status | /api/pair | /api/qr | /api/logout`)

  // Auto-start bot (pakai QR jika tidak ada sesi)
  startWhatsApp()
})
