# ⬡ NEXUS BOT — Setup Guide

## Struktur File
```
nexus-bot/
├── index.js          ← Backend utama (Node.js + Baileys)
├── package.json
├── sessions/         ← Otomatis dibuat saat bot login (jangan dihapus!)
└── public/
    └── bot-panel.html  ← Panel web (taruh di sini)
```

---

## 1. Install Dependencies

```bash
npm install
```

---

## 2. Jalankan Backend

```bash
node index.js
```

Atau pakai nodemon supaya auto-restart:
```bash
npx nodemon index.js
```

Backend jalan di: `http://localhost:3000`

---

## 3. Buka Panel Web

Buka file `bot-panel.html` di browser, atau akses:
```
http://localhost:3000
```
(taruh `bot-panel.html` di folder `public/`)

---

## 4. Login via Pairing Code

1. Di panel, masukkan nomor WA bot (format: `628123456789`)
2. Klik **"Minta Pairing Code"**
3. Kode 8 digit akan muncul (contoh: `ABCD-1234`)
4. Buka WhatsApp di HP → **⋮ Menu → Perangkat Tertaut → Tautkan Perangkat**
5. Pilih **"Tautkan dengan nomor telepon"**
6. Masukkan kode yang muncul di panel
7. Panel otomatis masuk setelah terhubung ✅

---

## 5. Deploy ke VPS / Railway

### Railway (gratis, mudah):
1. Push project ke GitHub
2. Buka [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Set environment variable: `PORT=3000`
4. Ganti `API` di `bot-panel.html`:
   ```js
   const API = 'https://nama-project.up.railway.app';
   ```

### VPS (Ubuntu):
```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# Clone / upload project
cd /home/nexus-bot
npm install

# Jalankan pakai PM2 (agar tetap jalan)
npm install -g pm2
pm2 start index.js --name nexus-bot
pm2 save
pm2 startup
```

---

## API Endpoints

| Method | Endpoint      | Keterangan                        |
|--------|---------------|-----------------------------------|
| GET    | /api/status   | Status koneksi bot                |
| POST   | /api/pair     | Minta pairing code `{phone}`      |
| GET    | /api/qr       | Ambil QR code (base64 PNG)        |
| POST   | /api/logout   | Logout & hapus sesi               |
| POST   | /api/send     | Kirim pesan `{to, text}`          |

---

## Tambah Command Bot

Edit bagian ini di `index.js`:

```js
if (text === '!ping')  await sock.sendMessage(from, { text: '🏓 Pong!' })
if (text === '!help')  await sock.sendMessage(from, { text: helpText() })
// Tambah command baru di sini:
if (text === '!harga') await sock.sendMessage(from, { text: 'Paket Premium: Rp 50.000/bulan' })
```

---

## Catatan Penting

- ⚠️ **Gunakan nomor WA khusus bot**, bukan nomor pribadi
- 📁 Folder `sessions/` menyimpan kredensial login — **jangan dihapus/share**
- 🔄 Jika bot logout sendiri, jalankan ulang `node index.js` dan login lagi
- 📵 WhatsApp bisa ban nomor jika terlalu banyak kirim pesan spam
